import { Navbar } from "@/components/navbar"
import { HeroSlider } from "@/components/hero-slider"
import { CategoryBanners } from "@/components/category-banners"
import { ProductSection } from "@/components/product-section"
import { NewsletterBanner } from "@/components/newsletter-banner"
import { Footer } from "@/components/footer"

const newArrivals = [
  {
    id: "1",
    name: "Linen Relaxed Shirt",
    category: "Womens",
    price: 89.00,
    image: "/images/product-1.jpg",
    href: "/products/linen-relaxed-shirt",
  },
  {
    id: "2",
    name: "Tailored Navy Blazer",
    category: "Mens",
    price: 195.00,
    image: "/images/product-2.jpg",
    href: "/products/tailored-navy-blazer",
  },
  {
    id: "3",
    name: "Wide Leg Trousers",
    category: "Womens",
    price: 120.00,
    image: "/images/product-3.jpg",
    href: "/products/wide-leg-trousers",
  },
  {
    id: "4",
    name: "Cotton A-Line Dress",
    category: "Womens",
    price: 145.00,
    image: "/images/product-4.jpg",
    href: "/products/cotton-a-line-dress",
  },
]

const bestSellers = [
  {
    id: "5",
    name: "Cashmere Crewneck",
    category: "Mens",
    price: 165.00,
    originalPrice: 220.00,
    image: "/images/product-5.jpg",
    href: "/products/cashmere-crewneck",
  },
  {
    id: "6",
    name: "Silk Button Blouse",
    category: "Womens",
    price: 135.00,
    image: "/images/product-6.jpg",
    href: "/products/silk-button-blouse",
  },
  {
    id: "7",
    name: "Classic Leather Belt",
    category: "Accessories",
    price: 75.00,
    image: "/images/product-7.jpg",
    href: "/products/classic-leather-belt",
  },
  {
    id: "8",
    name: "Wool Overcoat",
    category: "Mens",
    price: 295.00,
    originalPrice: 395.00,
    image: "/images/product-8.jpg",
    href: "/products/wool-overcoat",
  },
]

export default function Home() {
  return (
    <div className="min-h-screen bg-background">
      <Navbar cartItemCount={3} />

      <main>
        {/* Hero Slider */}
        <HeroSlider />

        {/* Category Entry Banners */}
        <CategoryBanners />

        {/* New Arrivals Section */}
        <ProductSection
          title="New Arrivals"
          viewAllHref="/new-arrivals"
          products={newArrivals}
        />

        {/* Best Sellers Section */}
        <ProductSection
          title="Best Sellers"
          viewAllHref="/best-sellers"
          products={bestSellers}
          variant="muted"
        />

        {/* Newsletter Banner */}
        <NewsletterBanner />
      </main>

      {/* Footer */}
      <Footer />
    </div>
  )
}
