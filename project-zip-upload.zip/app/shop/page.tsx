"use client"

import { useState, useMemo, useEffect } from "react"
import { useSearchParams } from "next/navigation"
import { Menu, X, SlidersHorizontal } from "lucide-react"
import { cn } from "@/lib/utils"
import { Navbar } from "@/components/navbar"
import { Footer } from "@/components/footer"
import { PLPProductCard, ProductColor } from "@/components/plp-product-card"
import {
  ProductFilters,
  ActiveFilters,
  FilterState,
} from "@/components/product-filters"
import { ProductPagination } from "@/components/product-pagination"
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select"

interface Product {
  id: string
  name: string
  category: string
  categoryType: "Mens" | "Womens"
  price: number
  originalPrice?: number
  image: string
  hoverImage?: string
  colors: ProductColor[]
  sizes: string[]
  colorNames: string[]
}

const PRODUCTS: Product[] = [
  {
    id: "1",
    name: "Linen Relaxed Shirt",
    category: "SHIRTS",
    categoryType: "Mens",
    price: 129.0,
    image: "/images/product-1.jpg",
    hoverImage: "/images/product-1-hover.jpg",
    colors: [
      { name: "Beige", hex: "#D4C5B5" },
      { name: "White", hex: "#FFFFFF" },
    ],
    sizes: ["S", "M", "L", "XL"],
    colorNames: ["Beige", "White"],
  },
  {
    id: "2",
    name: "Tailored Wool Blazer",
    category: "BLAZERS",
    categoryType: "Mens",
    price: 289.0,
    originalPrice: 359.0,
    image: "/images/product-2.jpg",
    hoverImage: "/images/product-2-hover.jpg",
    colors: [
      { name: "Navy", hex: "#1E3A5F" },
      { name: "Black", hex: "#1A1A1A" },
    ],
    sizes: ["S", "M", "L"],
    colorNames: ["Navy", "Black"],
  },
  {
    id: "3",
    name: "Wide Leg Trousers",
    category: "TROUSERS",
    categoryType: "Womens",
    price: 159.0,
    image: "/images/product-3.jpg",
    colors: [
      { name: "Beige", hex: "#D4C5B5" },
      { name: "Black", hex: "#1A1A1A" },
      { name: "Olive", hex: "#606B4A" },
    ],
    sizes: ["XS", "S", "M", "L"],
    colorNames: ["Beige", "Black", "Olive"],
  },
  {
    id: "4",
    name: "Cotton Midi Dress",
    category: "DRESSES",
    categoryType: "Womens",
    price: 189.0,
    image: "/images/product-4.jpg",
    colors: [
      { name: "White", hex: "#FFFFFF" },
      { name: "Beige", hex: "#D4C5B5" },
    ],
    sizes: ["XS", "S", "M", "L", "XL"],
    colorNames: ["White", "Beige"],
  },
  {
    id: "5",
    name: "Cashmere Crewneck Sweater",
    category: "KNITWEAR",
    categoryType: "Mens",
    price: 245.0,
    image: "/images/product-5.jpg",
    colors: [
      { name: "Black", hex: "#1A1A1A" },
      { name: "Navy", hex: "#1E3A5F" },
      { name: "Beige", hex: "#D4C5B5" },
    ],
    sizes: ["S", "M", "L", "XL"],
    colorNames: ["Black", "Navy", "Beige"],
  },
  {
    id: "6",
    name: "Silk Button Blouse",
    category: "TOPS",
    categoryType: "Womens",
    price: 175.0,
    originalPrice: 220.0,
    image: "/images/product-6.jpg",
    colors: [
      { name: "Olive", hex: "#606B4A" },
      { name: "White", hex: "#FFFFFF" },
    ],
    sizes: ["XS", "S", "M"],
    colorNames: ["Olive", "White"],
  },
  {
    id: "7",
    name: "Leather Belt",
    category: "ACCESSORIES",
    categoryType: "Mens",
    price: 89.0,
    image: "/images/product-7.jpg",
    colors: [
      { name: "Black", hex: "#1A1A1A" },
      { name: "Beige", hex: "#D4C5B5" },
    ],
    sizes: ["S", "M", "L"],
    colorNames: ["Black", "Beige"],
  },
  {
    id: "8",
    name: "Wool Overcoat",
    category: "OUTERWEAR",
    categoryType: "Womens",
    price: 395.0,
    image: "/images/product-8.jpg",
    colors: [
      { name: "Black", hex: "#1A1A1A" },
      { name: "Navy", hex: "#1E3A5F" },
    ],
    sizes: ["XS", "S", "M", "L"],
    colorNames: ["Black", "Navy"],
  },
  {
    id: "9",
    name: "Silk Midi Dress",
    category: "DRESSES",
    categoryType: "Womens",
    price: 265.0,
    image: "/images/product-9.jpg",
    colors: [
      { name: "Black", hex: "#1A1A1A" },
    ],
    sizes: ["XS", "S", "M", "L"],
    colorNames: ["Black"],
  },
  {
    id: "10",
    name: "Linen Blazer",
    category: "BLAZERS",
    categoryType: "Mens",
    price: 245.0,
    image: "/images/product-10.jpg",
    colors: [
      { name: "Olive", hex: "#606B4A" },
      { name: "Beige", hex: "#D4C5B5" },
    ],
    sizes: ["S", "M", "L", "XL"],
    colorNames: ["Olive", "Beige"],
  },
  {
    id: "11",
    name: "Cotton Oxford Shirt",
    category: "SHIRTS",
    categoryType: "Mens",
    price: 115.0,
    image: "/images/product-11.jpg",
    colors: [
      { name: "White", hex: "#FFFFFF" },
      { name: "Navy", hex: "#1E3A5F" },
    ],
    sizes: ["S", "M", "L", "XL"],
    colorNames: ["White", "Navy"],
  },
  {
    id: "12",
    name: "Knit Cardigan",
    category: "KNITWEAR",
    categoryType: "Womens",
    price: 195.0,
    originalPrice: 245.0,
    image: "/images/product-12.jpg",
    colors: [
      { name: "Beige", hex: "#D4C5B5" },
      { name: "Black", hex: "#1A1A1A" },
    ],
    sizes: ["XS", "S", "M", "L"],
    colorNames: ["Beige", "Black"],
  },
]

const MIN_PRICE = 0
const MAX_PRICE = 500
const PRODUCTS_PER_PAGE = 9

type SortOption = "newest" | "price-low" | "price-high" | "name"

export default function ProductListingPage() {
  const searchParams = useSearchParams()
  const categoryParam = searchParams.get("category")
  const saleParam = searchParams.get("sale")
  
  const [filters, setFilters] = useState<FilterState>({
    category: null,
    sizes: [],
    colors: [],
    priceRange: [MIN_PRICE, MAX_PRICE],
  })
  const [sortBy, setSortBy] = useState<SortOption>("newest")
  const [currentPage, setCurrentPage] = useState(1)
  const [mobileFiltersOpen, setMobileFiltersOpen] = useState(false)

  // Sync URL params with filters
  useEffect(() => {
    if (categoryParam === "Mens" || categoryParam === "Womens") {
      setFilters(prev => ({ ...prev, category: categoryParam }))
    } else {
      setFilters(prev => ({ ...prev, category: null }))
    }
  }, [categoryParam])

  // Get page title based on URL params
  const pageTitle = useMemo(() => {
    if (saleParam === "true") return "Sale"
    if (categoryParam === "Mens") return "Mens Collection"
    if (categoryParam === "Womens") return "Womens Collection"
    return "New Arrivals"
  }, [categoryParam, saleParam])

  const filteredProducts = useMemo(() => {
    let result = [...PRODUCTS]

    // Filter by sale (products with originalPrice)
    if (saleParam === "true") {
      result = result.filter((p) => p.originalPrice !== undefined)
    }

    // Filter by category
    if (filters.category) {
      result = result.filter((p) => p.categoryType === filters.category)
    }

    // Filter by sizes
    if (filters.sizes.length > 0) {
      result = result.filter((p) =>
        filters.sizes.some((size) => p.sizes.includes(size))
      )
    }

    // Filter by colors
    if (filters.colors.length > 0) {
      result = result.filter((p) =>
        filters.colors.some((color) => p.colorNames.includes(color))
      )
    }

    // Filter by price range
    result = result.filter(
      (p) => p.price >= filters.priceRange[0] && p.price <= filters.priceRange[1]
    )

    // Sort
    switch (sortBy) {
      case "price-low":
        result.sort((a, b) => a.price - b.price)
        break
      case "price-high":
        result.sort((a, b) => b.price - a.price)
        break
      case "name":
        result.sort((a, b) => a.name.localeCompare(b.name))
        break
      default:
        // newest - keep original order
        break
    }

    return result
  }, [filters, sortBy, saleParam])

  const totalPages = Math.ceil(filteredProducts.length / PRODUCTS_PER_PAGE)
  const paginatedProducts = filteredProducts.slice(
    (currentPage - 1) * PRODUCTS_PER_PAGE,
    currentPage * PRODUCTS_PER_PAGE
  )

  const handleRemoveFilter = (
    type: "category" | "size" | "color",
    value: string
  ) => {
    if (type === "category") {
      setFilters({ ...filters, category: null })
    } else if (type === "size") {
      setFilters({
        ...filters,
        sizes: filters.sizes.filter((s) => s !== value),
      })
    } else if (type === "color") {
      setFilters({
        ...filters,
        colors: filters.colors.filter((c) => c !== value),
      })
    }
    setCurrentPage(1)
  }

  const handleFiltersChange = (newFilters: FilterState) => {
    setFilters(newFilters)
    setCurrentPage(1)
  }

  const handlePageChange = (page: number) => {
    setCurrentPage(page)
    window.scrollTo({ top: 0, behavior: "smooth" })
  }

  // Determine active link for navbar
  const activeLink = useMemo(() => {
    if (saleParam === "true") return "/shop?sale=true"
    if (categoryParam === "Mens") return "/shop?category=Mens"
    if (categoryParam === "Womens") return "/shop?category=Womens"
    return "/shop"
  }, [categoryParam, saleParam])

  return (
    <div className="min-h-screen bg-background">
      <Navbar activeLink={activeLink} />

      <main className="pt-16">
        {/* Page Header */}
        <div className="border-b border-border">
          <div className="max-w-[1440px] mx-auto px-6 lg:px-12 py-8">
            <h1 className="font-serif text-3xl md:text-4xl text-foreground">
              {pageTitle}
            </h1>
          </div>
        </div>

        <div className="max-w-[1440px] mx-auto px-6 lg:px-12 py-8">
          <div className="flex gap-12">
            {/* Desktop Sidebar */}
            <div className="hidden lg:block">
              <ProductFilters
                filters={filters}
                onFiltersChange={handleFiltersChange}
                minPrice={MIN_PRICE}
                maxPrice={MAX_PRICE}
              />
            </div>

            {/* Main Content */}
            <div className="flex-1">
              {/* Top Bar */}
              <div className="flex items-center justify-between mb-6">
                <div className="flex items-center gap-4">
                  {/* Mobile Filter Button */}
                  <button
                    onClick={() => setMobileFiltersOpen(true)}
                    className="lg:hidden flex items-center gap-2 text-sm font-sans text-foreground"
                  >
                    <SlidersHorizontal className="w-4 h-4" />
                    <span>Filters</span>
                  </button>
                  
                  <p className="text-sm font-sans text-muted-foreground">
                    {filteredProducts.length} Products
                  </p>
                </div>

                <Select
                  value={sortBy}
                  onValueChange={(value) => setSortBy(value as SortOption)}
                >
                  <SelectTrigger className="w-auto border-0 shadow-none bg-transparent text-sm font-sans gap-2">
                    <span className="text-muted-foreground">Sort by:</span>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent align="end">
                    <SelectItem value="newest">Newest</SelectItem>
                    <SelectItem value="price-low">Price: Low to High</SelectItem>
                    <SelectItem value="price-high">Price: High to Low</SelectItem>
                    <SelectItem value="name">Name</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              {/* Active Filters */}
              <ActiveFilters
                filters={filters}
                onRemoveFilter={handleRemoveFilter}
              />

              {/* Product Grid */}
              {paginatedProducts.length > 0 ? (
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
                  {paginatedProducts.map((product) => (
                    <PLPProductCard
                      key={product.id}
                      id={product.id}
                      name={product.name}
                      category={product.category}
                      price={product.price}
                      originalPrice={product.originalPrice}
                      image={product.image}
                      hoverImage={product.hoverImage}
                      colors={product.colors}
                      href={`/product/${product.id}`}
                    />
                  ))}
                </div>
              ) : (
                <div className="text-center py-16">
                  <p className="text-muted-foreground font-sans">
                    No products match your filters.
                  </p>
                  <button
                    onClick={() =>
                      handleFiltersChange({
                        category: null,
                        sizes: [],
                        colors: [],
                        priceRange: [MIN_PRICE, MAX_PRICE],
                      })
                    }
                    className="mt-4 text-sm font-sans text-foreground underline underline-offset-4 hover:text-muted-foreground transition-colors"
                  >
                    Clear all filters
                  </button>
                </div>
              )}

              {/* Pagination */}
              {totalPages > 1 && (
                <ProductPagination
                  currentPage={currentPage}
                  totalPages={totalPages}
                  onPageChange={handlePageChange}
                />
              )}
            </div>
          </div>
        </div>

        {/* Mobile Filters Drawer */}
        <div
          className={cn(
            "fixed inset-0 z-50 lg:hidden transition-opacity duration-300",
            mobileFiltersOpen
              ? "opacity-100 pointer-events-auto"
              : "opacity-0 pointer-events-none"
          )}
        >
          {/* Overlay */}
          <div
            className="absolute inset-0 bg-foreground/20"
            onClick={() => setMobileFiltersOpen(false)}
          />

          {/* Drawer */}
          <div
            className={cn(
              "absolute left-0 top-0 h-full w-[300px] bg-background p-6 overflow-y-auto transition-transform duration-300",
              mobileFiltersOpen ? "translate-x-0" : "-translate-x-full"
            )}
          >
            <div className="flex items-center justify-between mb-8">
              <h2 className="text-[11px] font-sans tracking-[0.2em] text-foreground uppercase">
                Filters
              </h2>
              <button
                onClick={() => setMobileFiltersOpen(false)}
                className="p-2 -mr-2"
                aria-label="Close filters"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Filter Sections */}
            <div className="space-y-6">
              {/* Category */}
              <div className="pb-6 border-b border-border">
                <h3 className="text-[11px] font-sans tracking-[0.15em] text-muted-foreground uppercase mb-4">
                  Category
                </h3>
                <div className="space-y-3">
                  {["Mens", "Womens"].map((category) => (
                    <label
                      key={category}
                      className="flex items-center gap-3 cursor-pointer"
                    >
                      <span
                        className={cn(
                          "w-4 h-4 rounded-full border border-border flex items-center justify-center",
                          filters.category === category && "border-foreground"
                        )}
                      >
                        {filters.category === category && (
                          <span className="w-2 h-2 rounded-full bg-foreground" />
                        )}
                      </span>
                      <span
                        className="text-sm font-sans text-foreground"
                        onClick={() => {
                          handleFiltersChange({
                            ...filters,
                            category:
                              filters.category === category ? null : category,
                          })
                        }}
                      >
                        {category}
                      </span>
                    </label>
                  ))}
                </div>
              </div>

              {/* Size */}
              <div className="pb-6 border-b border-border">
                <h3 className="text-[11px] font-sans tracking-[0.15em] text-muted-foreground uppercase mb-4">
                  Size
                </h3>
                <div className="flex flex-wrap gap-2">
                  {["XS", "S", "M", "L", "XL"].map((size) => (
                    <button
                      key={size}
                      onClick={() => {
                        const newSizes = filters.sizes.includes(size)
                          ? filters.sizes.filter((s) => s !== size)
                          : [...filters.sizes, size]
                        handleFiltersChange({ ...filters, sizes: newSizes })
                      }}
                      className={cn(
                        "px-3 py-1.5 text-xs font-sans tracking-wide border transition-colors",
                        filters.sizes.includes(size)
                          ? "bg-foreground text-background border-foreground"
                          : "bg-transparent text-foreground border-border"
                      )}
                    >
                      {size}
                    </button>
                  ))}
                </div>
              </div>

              {/* Color */}
              <div className="pb-6 border-b border-border">
                <h3 className="text-[11px] font-sans tracking-[0.15em] text-muted-foreground uppercase mb-4">
                  Color
                </h3>
                <div className="flex flex-wrap gap-3">
                  {[
                    { name: "Black", hex: "#1A1A1A" },
                    { name: "White", hex: "#FFFFFF" },
                    { name: "Beige", hex: "#D4C5B5" },
                    { name: "Navy", hex: "#1E3A5F" },
                    { name: "Olive", hex: "#606B4A" },
                  ].map((color) => (
                    <button
                      key={color.name}
                      onClick={() => {
                        const newColors = filters.colors.includes(color.name)
                          ? filters.colors.filter((c) => c !== color.name)
                          : [...filters.colors, color.name]
                        handleFiltersChange({ ...filters, colors: newColors })
                      }}
                      className={cn(
                        "w-7 h-7 rounded-full transition-all",
                        color.hex === "#FFFFFF" && "border border-border",
                        filters.colors.includes(color.name)
                          ? "ring-2 ring-foreground ring-offset-2 ring-offset-background"
                          : ""
                      )}
                      style={{ backgroundColor: color.hex }}
                      title={color.name}
                    />
                  ))}
                </div>
              </div>
            </div>

            {/* Apply Button */}
            <button
              onClick={() => setMobileFiltersOpen(false)}
              className="w-full mt-8 py-3 bg-foreground text-background text-sm font-sans tracking-wide"
            >
              APPLY FILTERS
            </button>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
