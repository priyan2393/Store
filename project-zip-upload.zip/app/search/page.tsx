"use client"

import { useState, useMemo } from "react"
import { Search, X, SlidersHorizontal } from "lucide-react"
import { cn } from "@/lib/utils"
import { Navbar } from "@/components/navbar"
import { Footer } from "@/components/footer"
import { PLPProductCard, ProductColor } from "@/components/plp-product-card"
import {
  ProductFilters,
  ActiveFilters,
  FilterState,
} from "@/components/product-filters"
import { ProductPagination } from "@/components/product-pagination"
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select"
import Link from "next/link"

interface Product {
  id: string
  name: string
  category: string
  categoryType: "Mens" | "Womens"
  price: number
  originalPrice?: number
  image: string
  hoverImage?: string
  colors: ProductColor[]
  sizes: string[]
  colorNames: string[]
  searchTerms: string[]
}

const PRODUCTS: Product[] = [
  {
    id: "1",
    name: "Blue Linen Relaxed Shirt",
    category: "SHIRTS",
    categoryType: "Mens",
    price: 129.0,
    image: "/images/product-1.jpg",
    hoverImage: "/images/product-1-hover.jpg",
    colors: [
      { name: "Navy", hex: "#1E3A5F" },
      { name: "White", hex: "#FFFFFF" },
    ],
    sizes: ["S", "M", "L", "XL"],
    colorNames: ["Navy", "White"],
    searchTerms: ["blue", "linen", "shirt", "relaxed"],
  },
  {
    id: "2",
    name: "Tailored Wool Blazer",
    category: "BLAZERS",
    categoryType: "Mens",
    price: 289.0,
    originalPrice: 359.0,
    image: "/images/product-2.jpg",
    hoverImage: "/images/product-2-hover.jpg",
    colors: [
      { name: "Navy", hex: "#1E3A5F" },
      { name: "Black", hex: "#1A1A1A" },
    ],
    sizes: ["S", "M", "L"],
    colorNames: ["Navy", "Black"],
    searchTerms: ["wool", "blazer", "tailored", "navy", "blue"],
  },
  {
    id: "3",
    name: "Wide Leg Linen Trousers",
    category: "TROUSERS",
    categoryType: "Womens",
    price: 159.0,
    image: "/images/product-3.jpg",
    colors: [
      { name: "Beige", hex: "#D4C5B5" },
      { name: "Navy", hex: "#1E3A5F" },
      { name: "Olive", hex: "#606B4A" },
    ],
    sizes: ["XS", "S", "M", "L"],
    colorNames: ["Beige", "Navy", "Olive"],
    searchTerms: ["linen", "trousers", "wide", "leg", "blue", "navy"],
  },
  {
    id: "4",
    name: "Cotton Midi Dress",
    category: "DRESSES",
    categoryType: "Womens",
    price: 189.0,
    image: "/images/product-4.jpg",
    colors: [
      { name: "White", hex: "#FFFFFF" },
      { name: "Beige", hex: "#D4C5B5" },
    ],
    sizes: ["XS", "S", "M", "L", "XL"],
    colorNames: ["White", "Beige"],
    searchTerms: ["cotton", "dress", "midi"],
  },
  {
    id: "5",
    name: "Blue Cashmere Crewneck",
    category: "KNITWEAR",
    categoryType: "Mens",
    price: 245.0,
    image: "/images/product-5.jpg",
    colors: [
      { name: "Navy", hex: "#1E3A5F" },
      { name: "Black", hex: "#1A1A1A" },
      { name: "Beige", hex: "#D4C5B5" },
    ],
    sizes: ["S", "M", "L", "XL"],
    colorNames: ["Navy", "Black", "Beige"],
    searchTerms: ["cashmere", "sweater", "crewneck", "blue", "navy"],
  },
  {
    id: "6",
    name: "Silk Button Blouse",
    category: "TOPS",
    categoryType: "Womens",
    price: 175.0,
    originalPrice: 220.0,
    image: "/images/product-6.jpg",
    colors: [
      { name: "Olive", hex: "#606B4A" },
      { name: "White", hex: "#FFFFFF" },
    ],
    sizes: ["XS", "S", "M"],
    colorNames: ["Olive", "White"],
    searchTerms: ["silk", "blouse", "button"],
  },
  {
    id: "7",
    name: "Blue Linen Summer Shorts",
    category: "SHORTS",
    categoryType: "Mens",
    price: 89.0,
    image: "/images/product-7.jpg",
    colors: [
      { name: "Navy", hex: "#1E3A5F" },
      { name: "Beige", hex: "#D4C5B5" },
    ],
    sizes: ["S", "M", "L"],
    colorNames: ["Navy", "Beige"],
    searchTerms: ["linen", "shorts", "summer", "blue", "navy"],
  },
  {
    id: "8",
    name: "Wool Overcoat",
    category: "OUTERWEAR",
    categoryType: "Womens",
    price: 395.0,
    image: "/images/product-8.jpg",
    colors: [
      { name: "Black", hex: "#1A1A1A" },
      { name: "Navy", hex: "#1E3A5F" },
    ],
    sizes: ["XS", "S", "M", "L"],
    colorNames: ["Black", "Navy"],
    searchTerms: ["wool", "coat", "overcoat", "navy", "blue"],
  },
  {
    id: "9",
    name: "Linen Wrap Dress",
    category: "DRESSES",
    categoryType: "Womens",
    price: 265.0,
    image: "/images/product-9.jpg",
    colors: [
      { name: "Navy", hex: "#1E3A5F" },
    ],
    sizes: ["XS", "S", "M", "L"],
    colorNames: ["Navy"],
    searchTerms: ["linen", "dress", "wrap", "blue", "navy"],
  },
  {
    id: "10",
    name: "Blue Linen Blazer",
    category: "BLAZERS",
    categoryType: "Mens",
    price: 245.0,
    image: "/images/product-10.jpg",
    colors: [
      { name: "Navy", hex: "#1E3A5F" },
      { name: "Beige", hex: "#D4C5B5" },
    ],
    sizes: ["S", "M", "L", "XL"],
    colorNames: ["Navy", "Beige"],
    searchTerms: ["linen", "blazer", "blue", "navy"],
  },
  {
    id: "11",
    name: "Cotton Oxford Shirt",
    category: "SHIRTS",
    categoryType: "Mens",
    price: 115.0,
    image: "/images/product-11.jpg",
    colors: [
      { name: "White", hex: "#FFFFFF" },
      { name: "Navy", hex: "#1E3A5F" },
    ],
    sizes: ["S", "M", "L", "XL"],
    colorNames: ["White", "Navy"],
    searchTerms: ["cotton", "oxford", "shirt", "blue", "navy"],
  },
  {
    id: "12",
    name: "Linen Knit Cardigan",
    category: "KNITWEAR",
    categoryType: "Womens",
    price: 195.0,
    originalPrice: 245.0,
    image: "/images/product-12.jpg",
    colors: [
      { name: "Navy", hex: "#1E3A5F" },
      { name: "Beige", hex: "#D4C5B5" },
    ],
    sizes: ["XS", "S", "M", "L"],
    colorNames: ["Navy", "Beige"],
    searchTerms: ["linen", "knit", "cardigan", "blue", "navy"],
  },
  {
    id: "13",
    name: "Blue Linen Palazzo Pants",
    category: "TROUSERS",
    categoryType: "Womens",
    price: 145.0,
    image: "/images/product-3.jpg",
    colors: [
      { name: "Navy", hex: "#1E3A5F" },
    ],
    sizes: ["XS", "S", "M", "L"],
    colorNames: ["Navy"],
    searchTerms: ["linen", "palazzo", "pants", "blue", "navy"],
  },
  {
    id: "14",
    name: "Blue Linen Camp Collar Shirt",
    category: "SHIRTS",
    categoryType: "Mens",
    price: 135.0,
    image: "/images/product-1.jpg",
    colors: [
      { name: "Navy", hex: "#1E3A5F" },
      { name: "Olive", hex: "#606B4A" },
    ],
    sizes: ["S", "M", "L", "XL"],
    colorNames: ["Navy", "Olive"],
    searchTerms: ["linen", "camp", "collar", "shirt", "blue", "navy"],
  },
  {
    id: "15",
    name: "Linen Blend Jumpsuit",
    category: "JUMPSUITS",
    categoryType: "Womens",
    price: 225.0,
    image: "/images/product-4.jpg",
    colors: [
      { name: "Navy", hex: "#1E3A5F" },
      { name: "Beige", hex: "#D4C5B5" },
    ],
    sizes: ["XS", "S", "M", "L"],
    colorNames: ["Navy", "Beige"],
    searchTerms: ["linen", "jumpsuit", "blue", "navy"],
  },
  {
    id: "16",
    name: "Blue Striped Linen Shirt",
    category: "SHIRTS",
    categoryType: "Mens",
    price: 125.0,
    image: "/images/product-11.jpg",
    colors: [
      { name: "Navy", hex: "#1E3A5F" },
      { name: "White", hex: "#FFFFFF" },
    ],
    sizes: ["S", "M", "L", "XL"],
    colorNames: ["Navy", "White"],
    searchTerms: ["linen", "striped", "shirt", "blue", "navy"],
  },
  {
    id: "17",
    name: "Linen Cropped Trousers",
    category: "TROUSERS",
    categoryType: "Womens",
    price: 139.0,
    image: "/images/product-3.jpg",
    colors: [
      { name: "Navy", hex: "#1E3A5F" },
      { name: "White", hex: "#FFFFFF" },
    ],
    sizes: ["XS", "S", "M", "L"],
    colorNames: ["Navy", "White"],
    searchTerms: ["linen", "cropped", "trousers", "blue", "navy"],
  },
  {
    id: "18",
    name: "Blue Linen Maxi Skirt",
    category: "SKIRTS",
    categoryType: "Womens",
    price: 155.0,
    image: "/images/product-4.jpg",
    colors: [
      { name: "Navy", hex: "#1E3A5F" },
    ],
    sizes: ["XS", "S", "M", "L"],
    colorNames: ["Navy"],
    searchTerms: ["linen", "maxi", "skirt", "blue", "navy"],
  },
]

const MIN_PRICE = 0
const MAX_PRICE = 500
const PRODUCTS_PER_PAGE = 9

type SortOption = "relevance" | "newest" | "price-low" | "price-high" | "name"

/* Empty State Illustration */
function EmptyStateIllustration() {
  return (
    <svg
      width="120"
      height="120"
      viewBox="0 0 120 120"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      className="mx-auto mb-6"
    >
      {/* Search magnifying glass */}
      <circle
        cx="52"
        cy="52"
        r="28"
        stroke="#E5E0DB"
        strokeWidth="2"
        fill="none"
      />
      <line
        x1="72"
        y1="72"
        x2="95"
        y2="95"
        stroke="#E5E0DB"
        strokeWidth="2"
        strokeLinecap="round"
      />
      {/* X mark inside */}
      <line
        x1="42"
        y1="42"
        x2="62"
        y2="62"
        stroke="#E5E0DB"
        strokeWidth="1.5"
        strokeLinecap="round"
      />
      <line
        x1="62"
        y1="42"
        x2="42"
        y2="62"
        stroke="#E5E0DB"
        strokeWidth="1.5"
        strokeLinecap="round"
      />
      {/* Small decorative circles */}
      <circle cx="25" cy="30" r="3" stroke="#E5E0DB" strokeWidth="1" fill="none" />
      <circle cx="95" cy="25" r="2" stroke="#E5E0DB" strokeWidth="1" fill="none" />
      <circle cx="15" cy="75" r="2" stroke="#E5E0DB" strokeWidth="1" fill="none" />
    </svg>
  )
}

export default function SearchResultsPage() {
  const [searchQuery, setSearchQuery] = useState("blue linen")
  const [inputValue, setInputValue] = useState("blue linen")
  const [filters, setFilters] = useState<FilterState>({
    category: null,
    sizes: [],
    colors: [],
    priceRange: [MIN_PRICE, MAX_PRICE],
  })
  const [sortBy, setSortBy] = useState<SortOption>("relevance")
  const [currentPage, setCurrentPage] = useState(1)
  const [mobileFiltersOpen, setMobileFiltersOpen] = useState(false)
  const [showEmptyDemo, setShowEmptyDemo] = useState(false)

  const searchedProducts = useMemo(() => {
    if (!searchQuery.trim() || showEmptyDemo) return []
    
    const terms = searchQuery.toLowerCase().split(" ").filter(Boolean)
    return PRODUCTS.filter((product) =>
      terms.every((term) =>
        product.searchTerms.some((searchTerm) => searchTerm.includes(term)) ||
        product.name.toLowerCase().includes(term) ||
        product.category.toLowerCase().includes(term)
      )
    )
  }, [searchQuery, showEmptyDemo])

  const filteredProducts = useMemo(() => {
    let result = [...searchedProducts]

    // Filter by category
    if (filters.category) {
      result = result.filter((p) => p.categoryType === filters.category)
    }

    // Filter by sizes
    if (filters.sizes.length > 0) {
      result = result.filter((p) =>
        filters.sizes.some((size) => p.sizes.includes(size))
      )
    }

    // Filter by colors
    if (filters.colors.length > 0) {
      result = result.filter((p) =>
        filters.colors.some((color) => p.colorNames.includes(color))
      )
    }

    // Filter by price range
    result = result.filter(
      (p) => p.price >= filters.priceRange[0] && p.price <= filters.priceRange[1]
    )

    // Sort
    switch (sortBy) {
      case "price-low":
        result.sort((a, b) => a.price - b.price)
        break
      case "price-high":
        result.sort((a, b) => b.price - a.price)
        break
      case "name":
        result.sort((a, b) => a.name.localeCompare(b.name))
        break
      default:
        // relevance or newest - keep order from search
        break
    }

    return result
  }, [searchedProducts, filters, sortBy])

  const totalPages = Math.ceil(filteredProducts.length / PRODUCTS_PER_PAGE)
  const paginatedProducts = filteredProducts.slice(
    (currentPage - 1) * PRODUCTS_PER_PAGE,
    currentPage * PRODUCTS_PER_PAGE
  )

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault()
    setSearchQuery(inputValue)
    setCurrentPage(1)
    setShowEmptyDemo(false)
  }

  const handleClearSearch = () => {
    setInputValue("")
    setSearchQuery("")
    setCurrentPage(1)
  }

  const handleRemoveFilter = (
    type: "category" | "size" | "color",
    value: string
  ) => {
    if (type === "category") {
      setFilters({ ...filters, category: null })
    } else if (type === "size") {
      setFilters({
        ...filters,
        sizes: filters.sizes.filter((s) => s !== value),
      })
    } else if (type === "color") {
      setFilters({
        ...filters,
        colors: filters.colors.filter((c) => c !== value),
      })
    }
    setCurrentPage(1)
  }

  const handleFiltersChange = (newFilters: FilterState) => {
    setFilters(newFilters)
    setCurrentPage(1)
  }

  const handlePageChange = (page: number) => {
    setCurrentPage(page)
    window.scrollTo({ top: 0, behavior: "smooth" })
  }

  const showResults = searchQuery.trim() && filteredProducts.length > 0
  const showEmptyState = !showResults && (searchQuery.trim() || showEmptyDemo)

  return (
    <div className="min-h-screen bg-background">
      <Navbar />

      <main className="pt-16">
        {/* Search Section */}
        <div className="border-b border-border">
          <div className="max-w-[1440px] mx-auto px-6 lg:px-12 py-12">
            {/* Search Bar */}
            <form onSubmit={handleSearch} className="flex justify-center mb-6">
              <div className="relative w-full max-w-[600px]">
                <div className="absolute left-4 top-1/2 -translate-y-1/2 pointer-events-none">
                  <Search className="w-5 h-5 text-muted-foreground" />
                </div>
                <input
                  type="text"
                  value={inputValue}
                  onChange={(e) => setInputValue(e.target.value)}
                  placeholder="Search for products..."
                  className="w-full h-[52px] pl-12 pr-12 bg-background border border-border text-foreground font-sans text-base placeholder:text-muted-foreground focus:outline-none focus:border-foreground transition-colors"
                />
                {inputValue && (
                  <button
                    type="button"
                    onClick={handleClearSearch}
                    className="absolute right-4 top-1/2 -translate-y-1/2 p-1 hover:bg-muted rounded-sm transition-colors"
                    aria-label="Clear search"
                  >
                    <X className="w-4 h-4 text-muted-foreground" />
                  </button>
                )}
              </div>
            </form>

            {/* Results Count */}
            {searchQuery.trim() && !showEmptyDemo && (
              <p className="text-center text-sm font-sans text-muted-foreground">
                Showing {filteredProducts.length} results for &apos;{searchQuery}&apos;
              </p>
            )}

            {/* Demo Toggle */}
            <div className="flex justify-center mt-4">
              <button
                onClick={() => setShowEmptyDemo(!showEmptyDemo)}
                className="text-xs font-sans text-muted-foreground hover:text-foreground underline underline-offset-4 transition-colors"
              >
                {showEmptyDemo ? "Show results" : "View empty state"}
              </button>
            </div>
          </div>
        </div>

        {/* Empty State */}
        {showEmptyState && (
          <div className="max-w-[1440px] mx-auto px-6 lg:px-12 py-20">
            <div className="flex flex-col items-center text-center">
              <EmptyStateIllustration />
              <h2 className="font-serif text-2xl md:text-3xl text-foreground mb-3">
                No results found
              </h2>
              <p className="text-sm font-sans text-muted-foreground mb-8 max-w-md">
                Try different keywords or browse our categories
              </p>
              <div className="flex flex-col sm:flex-row gap-3">
                <Link
                  href="/shop?category=Mens"
                  className="px-8 py-3 bg-foreground text-background text-sm font-sans tracking-wide hover:bg-foreground/90 transition-colors"
                >
                  SHOP MENS
                </Link>
                <Link
                  href="/shop?category=Womens"
                  className="px-8 py-3 bg-background text-foreground text-sm font-sans tracking-wide border border-foreground hover:bg-muted transition-colors"
                >
                  SHOP WOMENS
                </Link>
              </div>
            </div>
          </div>
        )}

        {/* Results */}
        {showResults && (
          <div className="max-w-[1440px] mx-auto px-6 lg:px-12 py-8">
            <div className="flex gap-12">
              {/* Desktop Sidebar */}
              <div className="hidden lg:block">
                <ProductFilters
                  filters={filters}
                  onFiltersChange={handleFiltersChange}
                  minPrice={MIN_PRICE}
                  maxPrice={MAX_PRICE}
                />
              </div>

              {/* Main Content */}
              <div className="flex-1">
                {/* Top Bar */}
                <div className="flex items-center justify-between mb-6">
                  <div className="flex items-center gap-4">
                    {/* Mobile Filter Button */}
                    <button
                      onClick={() => setMobileFiltersOpen(true)}
                      className="lg:hidden flex items-center gap-2 text-sm font-sans text-foreground"
                    >
                      <SlidersHorizontal className="w-4 h-4" />
                      <span>Filters</span>
                    </button>

                    <p className="text-sm font-sans text-muted-foreground">
                      {filteredProducts.length} Products
                    </p>
                  </div>

                  <Select
                    value={sortBy}
                    onValueChange={(value) => setSortBy(value as SortOption)}
                  >
                    <SelectTrigger className="w-auto border-0 shadow-none bg-transparent text-sm font-sans gap-2">
                      <span className="text-muted-foreground">Sort by:</span>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent align="end">
                      <SelectItem value="relevance">Relevance</SelectItem>
                      <SelectItem value="newest">Newest</SelectItem>
                      <SelectItem value="price-low">Price: Low to High</SelectItem>
                      <SelectItem value="price-high">Price: High to Low</SelectItem>
                      <SelectItem value="name">Name</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                {/* Active Filters */}
                <ActiveFilters
                  filters={filters}
                  onRemoveFilter={handleRemoveFilter}
                />

                {/* Product Grid */}
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
                  {paginatedProducts.map((product) => (
                    <PLPProductCard
                      key={product.id}
                      id={product.id}
                      name={product.name}
                      category={product.category}
                      price={product.price}
                      originalPrice={product.originalPrice}
                      image={product.image}
                      hoverImage={product.hoverImage}
                      colors={product.colors}
                      href={`/product/${product.id}`}
                    />
                  ))}
                </div>

                {/* Pagination */}
                {totalPages > 1 && (
                  <ProductPagination
                    currentPage={currentPage}
                    totalPages={totalPages}
                    onPageChange={handlePageChange}
                  />
                )}
              </div>
            </div>
          </div>
        )}

        {/* Mobile Filters Drawer */}
        <div
          className={cn(
            "fixed inset-0 z-50 lg:hidden transition-opacity duration-300",
            mobileFiltersOpen
              ? "opacity-100 pointer-events-auto"
              : "opacity-0 pointer-events-none"
          )}
        >
          {/* Overlay */}
          <div
            className="absolute inset-0 bg-foreground/20"
            onClick={() => setMobileFiltersOpen(false)}
          />

          {/* Drawer */}
          <div
            className={cn(
              "absolute left-0 top-0 h-full w-[300px] bg-background p-6 overflow-y-auto transition-transform duration-300",
              mobileFiltersOpen ? "translate-x-0" : "-translate-x-full"
            )}
          >
            <div className="flex items-center justify-between mb-8">
              <h2 className="text-[11px] font-sans tracking-[0.2em] text-foreground uppercase">
                Filters
              </h2>
              <button
                onClick={() => setMobileFiltersOpen(false)}
                className="p-2 -mr-2"
                aria-label="Close filters"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Filter Sections */}
            <div className="space-y-6">
              {/* Category */}
              <div className="pb-6 border-b border-border">
                <h3 className="text-[11px] font-sans tracking-[0.15em] text-muted-foreground uppercase mb-4">
                  Category
                </h3>
                <div className="space-y-3">
                  {["Mens", "Womens"].map((category) => (
                    <label
                      key={category}
                      className="flex items-center gap-3 cursor-pointer"
                    >
                      <span
                        className={cn(
                          "w-4 h-4 rounded-full border border-border flex items-center justify-center",
                          filters.category === category && "border-foreground"
                        )}
                      >
                        {filters.category === category && (
                          <span className="w-2 h-2 rounded-full bg-foreground" />
                        )}
                      </span>
                      <span
                        className="text-sm font-sans text-foreground"
                        onClick={() => {
                          handleFiltersChange({
                            ...filters,
                            category:
                              filters.category === category ? null : category,
                          })
                        }}
                      >
                        {category}
                      </span>
                    </label>
                  ))}
                </div>
              </div>

              {/* Size */}
              <div className="pb-6 border-b border-border">
                <h3 className="text-[11px] font-sans tracking-[0.15em] text-muted-foreground uppercase mb-4">
                  Size
                </h3>
                <div className="flex flex-wrap gap-2">
                  {["XS", "S", "M", "L", "XL"].map((size) => (
                    <button
                      key={size}
                      onClick={() => {
                        const newSizes = filters.sizes.includes(size)
                          ? filters.sizes.filter((s) => s !== size)
                          : [...filters.sizes, size]
                        handleFiltersChange({ ...filters, sizes: newSizes })
                      }}
                      className={cn(
                        "px-3 py-1.5 text-xs font-sans tracking-wide border transition-colors",
                        filters.sizes.includes(size)
                          ? "bg-foreground text-background border-foreground"
                          : "bg-transparent text-foreground border-border"
                      )}
                    >
                      {size}
                    </button>
                  ))}
                </div>
              </div>

              {/* Color */}
              <div className="pb-6 border-b border-border">
                <h3 className="text-[11px] font-sans tracking-[0.15em] text-muted-foreground uppercase mb-4">
                  Color
                </h3>
                <div className="flex flex-wrap gap-3">
                  {[
                    { name: "Black", hex: "#1A1A1A" },
                    { name: "White", hex: "#FFFFFF" },
                    { name: "Beige", hex: "#D4C5B5" },
                    { name: "Navy", hex: "#1E3A5F" },
                    { name: "Olive", hex: "#606B4A" },
                  ].map((color) => (
                    <button
                      key={color.name}
                      onClick={() => {
                        const newColors = filters.colors.includes(color.name)
                          ? filters.colors.filter((c) => c !== color.name)
                          : [...filters.colors, color.name]
                        handleFiltersChange({ ...filters, colors: newColors })
                      }}
                      className={cn(
                        "w-7 h-7 rounded-full transition-all",
                        color.hex === "#FFFFFF" && "border border-border",
                        filters.colors.includes(color.name)
                          ? "ring-2 ring-foreground ring-offset-2 ring-offset-background"
                          : ""
                      )}
                      style={{ backgroundColor: color.hex }}
                      title={color.name}
                    />
                  ))}
                </div>
              </div>
            </div>

            {/* Apply Button */}
            <button
              onClick={() => setMobileFiltersOpen(false)}
              className="w-full mt-8 py-3 bg-foreground text-background text-sm font-sans tracking-wide"
            >
              APPLY FILTERS
            </button>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
