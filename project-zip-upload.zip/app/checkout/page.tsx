"use client"

import { useState } from "react"
import Link from "next/link"
import { useRouter } from "next/navigation"
import { ArrowLeft, Shield, Truck, RotateCcw } from "lucide-react"
import { Navbar } from "@/components/navbar"
import { CheckoutSteps } from "@/components/checkout/checkout-steps"
import { AddressForm, type AddressFormValues } from "@/components/checkout/address-form"
import { OrderSummary, type OrderItem } from "@/components/checkout/order-summary"

// Mock order data
const ORDER_ITEMS: OrderItem[] = [
  {
    id: "1",
    name: "Linen Blend Relaxed Shirt",
    variant: "Off White / M",
    price: 3490,
    quantity: 1,
    image: "https://images.unsplash.com/photo-1596755094514-f87e34085b2c?w=200&q=80",
  },
  {
    id: "2",
    name: "Cotton Wide Leg Trousers",
    variant: "Black / S",
    price: 4290,
    quantity: 2,
    image: "https://images.unsplash.com/photo-1594938298603-c8148c4dae35?w=200&q=80",
  },
  {
    id: "3",
    name: "Handwoven Kantha Jacket",
    variant: "Indigo / L",
    price: 7990,
    quantity: 1,
    image: "https://images.unsplash.com/photo-1591047139829-d91aecb6caea?w=200&q=80",
  },
]

const SUBTOTAL = ORDER_ITEMS.reduce(
  (sum, item) => sum + item.price * item.quantity,
  0
)
const DISCOUNT = 990
const DELIVERY = SUBTOTAL - DISCOUNT > 3000 ? 0 : 199

const TRUST_BADGES = [
  { icon: Shield, label: "Secure Checkout", sub: "256-bit SSL encryption" },
  { icon: Truck, label: "Free Delivery", sub: "On orders above ₹3,000" },
  { icon: RotateCcw, label: "Easy Returns", sub: "30-day hassle-free returns" },
]

export default function CheckoutPage() {
  const router = useRouter()
  const [currentStep, setCurrentStep] = useState(1)

  const handleAddressSubmit = (values: AddressFormValues) => {
    // In production: save address to state/context, then advance step
    setCurrentStep(2)
    window.scrollTo({ top: 0, behavior: "smooth" })
  }

  return (
    <div className="min-h-screen bg-background">
      <Navbar cartItemCount={ORDER_ITEMS.reduce((s, i) => s + i.quantity, 0)} />

      <main className="max-w-[1440px] mx-auto px-4 lg:px-8 py-8 lg:py-12">

        {/* Breadcrumb */}
        <nav aria-label="Breadcrumb" className="flex items-center gap-2 mb-8">
          <Link
            href="/cart"
            className="flex items-center gap-1.5 text-[12px] font-sans tracking-[0.1em] text-muted-foreground hover:text-foreground transition-colors"
          >
            <ArrowLeft className="w-3.5 h-3.5" strokeWidth={1.5} />
            Back to Cart
          </Link>
        </nav>

        {/* Page heading */}
        <h1 className="font-serif text-3xl lg:text-4xl text-foreground mb-8 lg:mb-10 tracking-wide">
          Checkout
        </h1>

        {/* Two-column layout */}
        <div className="flex flex-col lg:flex-row gap-10 xl:gap-16 items-start">

          {/* LEFT — 60% — Form */}
          <div className="w-full lg:w-[60%] xl:w-[62%]">

            {/* Step indicator */}
            <CheckoutSteps currentStep={currentStep} />

            {/* Address Form (Step 1) */}
            {currentStep === 1 && (
              <AddressForm isLoggedIn={true} onSubmit={handleAddressSubmit} />
            )}

            {/* Payment placeholder (Step 2) */}
            {currentStep === 2 && (
              <div className="space-y-6">
                <h2 className="font-serif text-2xl text-foreground tracking-wide">
                  Payment
                </h2>
                <div className="border border-border p-8 text-center">
                  <p className="font-sans text-sm text-muted-foreground">
                    Payment step — coming soon.
                  </p>
                  <button
                    onClick={() => setCurrentStep(1)}
                    className="mt-4 text-[12px] font-sans tracking-[0.12em] text-foreground underline underline-offset-4"
                  >
                    Back to Address
                  </button>
                </div>
              </div>
            )}

            {/* Trust badges */}
            <div className="mt-10 pt-8 border-t border-border grid grid-cols-1 sm:grid-cols-3 gap-6">
              {TRUST_BADGES.map(({ icon: Icon, label, sub }) => (
                <div key={label} className="flex items-start gap-3">
                  <Icon
                    className="w-5 h-5 text-accent shrink-0 mt-0.5"
                    strokeWidth={1.5}
                  />
                  <div>
                    <p className="text-[12px] font-sans tracking-[0.1em] text-foreground">
                      {label}
                    </p>
                    <p className="text-[11px] font-sans text-muted-foreground mt-0.5">
                      {sub}
                    </p>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* RIGHT — 40% — Order Summary */}
          <div className="w-full lg:w-[40%] xl:w-[38%]">
            <OrderSummary
              items={ORDER_ITEMS}
              subtotal={SUBTOTAL}
              discount={DISCOUNT}
              delivery={DELIVERY}
            />
          </div>
        </div>
      </main>
    </div>
  )
}
