import { ProductGallery } from "@/components/product-gallery"
import { ProductInfo } from "@/components/product-info"
import { ProductCard } from "@/components/product-card"
import { Navbar } from "@/components/navbar"
import { Footer } from "@/components/footer"

// Mock product data
const product = {
  id: "silk-blouse-ivory",
  name: "Silk Relaxed Blouse",
  breadcrumb: {
    category: "Womens",
    subcategory: "Tops",
    categoryHref: "/shop?category=Womens",
    subcategoryHref: "/shop?category=Womens&subcategory=Tops",
  },
  rating: 4,
  reviewCount: 24,
  price: 185.00,
  originalPrice: 245.00,
  description: "An effortlessly elegant silk blouse with a relaxed silhouette. Crafted from luxurious mulberry silk, this piece transitions seamlessly from day to evening.",
  colors: [
    { name: "Ivory", value: "#F5F5DC" },
    { name: "Black", value: "#1A1A1A" },
    { name: "Dusty Rose", value: "#D4A5A5" },
    { name: "Navy", value: "#1C2841" },
  ],
  sizes: ["XS", "S", "M", "L", "XL"],
  stockCount: 3,
  images: [
    { src: "/images/pdp-main.jpg", alt: "Silk Relaxed Blouse - Front View" },
    { src: "/images/pdp-thumb-1.jpg", alt: "Silk Relaxed Blouse - Detail" },
    { src: "/images/pdp-thumb-2.jpg", alt: "Silk Relaxed Blouse - Side View" },
    { src: "/images/pdp-thumb-3.jpg", alt: "Silk Relaxed Blouse - Back View" },
    { src: "/images/pdp-thumb-4.jpg", alt: "Silk Relaxed Blouse - Styled" },
  ],
}

const relatedProducts = [
  {
    id: "linen-wide-trousers",
    name: "Linen Wide Trousers",
    category: "Womens",
    price: 165.00,
    image: "/images/product-3.jpg",
    href: "/product/linen-wide-trousers",
  },
  {
    id: "cashmere-sweater",
    name: "Cashmere Crew Sweater",
    category: "Womens",
    price: 295.00,
    originalPrice: 395.00,
    image: "/images/product-5.jpg",
    href: "/product/cashmere-sweater",
  },
  {
    id: "silk-midi-dress",
    name: "Silk Midi Dress",
    category: "Womens",
    price: 425.00,
    image: "/images/product-9.jpg",
    href: "/product/silk-midi-dress",
  },
  {
    id: "cotton-button-shirt",
    name: "Cotton Button Shirt",
    category: "Womens",
    price: 125.00,
    image: "/images/product-11.jpg",
    href: "/product/cotton-button-shirt",
  },
]

export default function ProductDetailPage() {
  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      
      <main>
        {/* Product Section */}
        <section className="py-12 md:py-16">
          <div className="max-w-[1200px] mx-auto px-6">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 lg:gap-16">
              {/* Left Column - Image Gallery */}
              <div className="order-1">
                <ProductGallery images={product.images} />
              </div>

              {/* Right Column - Product Info */}
              <div className="order-2">
                <ProductInfo
                  breadcrumb={product.breadcrumb}
                  name={product.name}
                  rating={product.rating}
                  reviewCount={product.reviewCount}
                  price={product.price}
                  originalPrice={product.originalPrice}
                  description={product.description}
                  colors={product.colors}
                  sizes={product.sizes}
                  stockCount={product.stockCount}
                />
              </div>
            </div>
          </div>
        </section>

        {/* Related Products Section */}
        <section className="py-16 border-t border-border">
          <div className="max-w-[1200px] mx-auto px-6">
            <h2 className="font-serif text-3xl text-foreground text-center mb-12">
              You May Also Like
            </h2>
            
            <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
              {relatedProducts.map((relatedProduct) => (
                <ProductCard
                  key={relatedProduct.id}
                  id={relatedProduct.id}
                  name={relatedProduct.name}
                  category={relatedProduct.category}
                  price={relatedProduct.price}
                  originalPrice={relatedProduct.originalPrice}
                  image={relatedProduct.image}
                  href={relatedProduct.href}
                />
              ))}
            </div>
          </div>
        </section>
      </main>

      <Footer />
    </div>
  )
}
