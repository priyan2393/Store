"use client"

import { useState } from "react"
import { MapPin, Plus, Pencil, Trash2 } from "lucide-react"
import { Button } from "@/components/ui/button"

interface Address {
  id: string
  name: string
  phone: string
  address: string
  city: string
  state: string
  pincode: string
  isDefault: boolean
}

const DEMO_ADDRESSES: Address[] = [
  {
    id: "1",
    name: "Priya Sharma",
    phone: "+91 98765 43210",
    address: "42, Lotus Apartments, MG Road",
    city: "Bengaluru",
    state: "Karnataka",
    pincode: "560001",
    isDefault: true,
  },
  {
    id: "2",
    name: "Priya Sharma",
    phone: "+91 98765 43210",
    address: "15, Ocean View, Bandra West",
    city: "Mumbai",
    state: "Maharashtra",
    pincode: "400050",
    isDefault: false,
  },
]

export default function AddressesPage() {
  const [addresses] = useState<Address[]>(DEMO_ADDRESSES)

  return (
    <div>
      <div className="flex items-center justify-between mb-8">
        <h1 className="font-serif text-3xl md:text-[30px] text-foreground">
          Saved Addresses
        </h1>
        <Button
          variant="outline"
          size="sm"
          className="h-9 text-xs font-sans rounded-none border-border hover:bg-muted gap-2"
        >
          <Plus className="w-4 h-4" />
          Add New
        </Button>
      </div>
      
      <div className="grid gap-4">
        {addresses.map((address) => (
          <div
            key={address.id}
            className="border border-border p-5 relative"
          >
            {address.isDefault && (
              <span className="absolute top-4 right-4 px-2 py-0.5 text-[10px] font-sans bg-accent/10 text-accent border border-accent/20 rounded-sm">
                Default
              </span>
            )}
            <div className="flex items-start gap-3">
              <MapPin className="w-5 h-5 text-muted-foreground flex-shrink-0 mt-0.5" strokeWidth={1.5} />
              <div className="flex-1 min-w-0">
                <p className="text-sm font-sans text-foreground mb-1">
                  {address.name}
                </p>
                <p className="text-sm text-muted-foreground font-sans">
                  {address.address}
                </p>
                <p className="text-sm text-muted-foreground font-sans">
                  {address.city}, {address.state} - {address.pincode}
                </p>
                <p className="text-sm text-muted-foreground font-sans mt-2">
                  {address.phone}
                </p>
              </div>
            </div>
            <div className="flex items-center gap-3 mt-4 pt-4 border-t border-border">
              <button className="flex items-center gap-1.5 text-xs font-sans text-muted-foreground hover:text-foreground transition-colors">
                <Pencil className="w-3.5 h-3.5" />
                Edit
              </button>
              <button className="flex items-center gap-1.5 text-xs font-sans text-destructive/70 hover:text-destructive transition-colors">
                <Trash2 className="w-3.5 h-3.5" />
                Remove
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  )
}
