"use client"

import { useState } from "react"
import { Eye, EyeOff } from "lucide-react"
import { Button } from "@/components/ui/button"

export default function PasswordPage() {
  const [showPasswords, setShowPasswords] = useState({
    current: false,
    new: false,
    confirm: false,
  })
  const [formData, setFormData] = useState({
    currentPassword: "",
    newPassword: "",
    confirmPassword: "",
  })

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    console.log("Password change submitted")
  }

  const toggleVisibility = (field: keyof typeof showPasswords) => {
    setShowPasswords((prev) => ({ ...prev, [field]: !prev[field] }))
  }

  return (
    <div>
      <h1 className="font-serif text-3xl md:text-[30px] text-foreground mb-8">
        Change Password
      </h1>
      
      <form onSubmit={handleSubmit} className="max-w-md space-y-6">
        {/* Current Password */}
        <div>
          <label className="block text-sm font-sans text-muted-foreground mb-2">
            Current Password
          </label>
          <div className="relative">
            <input
              type={showPasswords.current ? "text" : "password"}
              value={formData.currentPassword}
              onChange={(e) => setFormData({ ...formData, currentPassword: e.target.value })}
              className="w-full h-11 px-4 pr-12 border border-border bg-background text-sm font-sans text-foreground focus:outline-none focus:border-foreground transition-colors"
            />
            <button
              type="button"
              onClick={() => toggleVisibility("current")}
              className="absolute right-4 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground"
            >
              {showPasswords.current ? (
                <EyeOff className="w-4 h-4" />
              ) : (
                <Eye className="w-4 h-4" />
              )}
            </button>
          </div>
        </div>
        
        {/* New Password */}
        <div>
          <label className="block text-sm font-sans text-muted-foreground mb-2">
            New Password
          </label>
          <div className="relative">
            <input
              type={showPasswords.new ? "text" : "password"}
              value={formData.newPassword}
              onChange={(e) => setFormData({ ...formData, newPassword: e.target.value })}
              className="w-full h-11 px-4 pr-12 border border-border bg-background text-sm font-sans text-foreground focus:outline-none focus:border-foreground transition-colors"
            />
            <button
              type="button"
              onClick={() => toggleVisibility("new")}
              className="absolute right-4 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground"
            >
              {showPasswords.new ? (
                <EyeOff className="w-4 h-4" />
              ) : (
                <Eye className="w-4 h-4" />
              )}
            </button>
          </div>
          <p className="text-xs text-muted-foreground mt-2">
            Must be at least 8 characters with a number and special character.
          </p>
        </div>
        
        {/* Confirm Password */}
        <div>
          <label className="block text-sm font-sans text-muted-foreground mb-2">
            Confirm New Password
          </label>
          <div className="relative">
            <input
              type={showPasswords.confirm ? "text" : "password"}
              value={formData.confirmPassword}
              onChange={(e) => setFormData({ ...formData, confirmPassword: e.target.value })}
              className="w-full h-11 px-4 pr-12 border border-border bg-background text-sm font-sans text-foreground focus:outline-none focus:border-foreground transition-colors"
            />
            <button
              type="button"
              onClick={() => toggleVisibility("confirm")}
              className="absolute right-4 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground"
            >
              {showPasswords.confirm ? (
                <EyeOff className="w-4 h-4" />
              ) : (
                <Eye className="w-4 h-4" />
              )}
            </button>
          </div>
        </div>
        
        {/* Submit */}
        <Button
          type="submit"
          className="w-full h-11 bg-primary text-primary-foreground font-sans text-sm rounded-none hover:bg-primary/90"
        >
          Update Password
        </Button>
      </form>
    </div>
  )
}
