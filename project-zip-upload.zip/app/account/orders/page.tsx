import { OrdersList } from "@/components/account/orders-list"

export default function OrdersPage() {
  return (
    <div>
      {/* Page Heading */}
      <h1 className="font-serif text-3xl md:text-[30px] text-foreground mb-8">
        My Orders
      </h1>
      
      {/* Orders List with Filters */}
      <OrdersList />
    </div>
  )
}
