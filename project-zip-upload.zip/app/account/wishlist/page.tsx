import { Heart } from "lucide-react"

export default function WishlistPage() {
  return (
    <div>
      <h1 className="font-serif text-3xl md:text-[30px] text-foreground mb-8">
        Wishlist
      </h1>
      
      {/* Empty State */}
      <div className="py-16 text-center border border-border">
        <Heart className="w-12 h-12 text-muted-foreground mx-auto mb-4" strokeWidth={1} />
        <p className="text-muted-foreground font-sans mb-2">
          Your wishlist is empty
        </p>
        <p className="text-sm text-muted-foreground font-sans">
          Save your favorite items here to purchase later.
        </p>
      </div>
    </div>
  )
}
