import { Navbar } from "@/components/navbar"
import { Footer } from "@/components/footer"
import { AccountSidebar } from "@/components/account/account-sidebar"

export default function AccountLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <div className="min-h-screen bg-background flex flex-col">
      <Navbar />
      
      <main className="flex-1">
        <div className="max-w-7xl mx-auto px-4 md:px-6 lg:px-8 py-8 md:py-12">
          {/* Mobile: Stack, Desktop: Two columns */}
          <div className="flex flex-col lg:flex-row gap-8 lg:gap-12">
            {/* Sidebar - Hidden on mobile, shown on desktop */}
            <div className="hidden lg:block">
              <AccountSidebar />
            </div>
            
            {/* Mobile Account Header */}
            <div className="lg:hidden border-b border-border pb-6 mb-2">
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 rounded-full bg-muted flex items-center justify-center">
                  <span className="font-serif text-base text-foreground">
                    PS
                  </span>
                </div>
                <div>
                  <p className="font-serif text-lg text-foreground">
                    Priya Sharma
                  </p>
                  <p className="text-sm text-muted-foreground">
                    priya.sharma@email.com
                  </p>
                </div>
              </div>
            </div>
            
            {/* Content Area */}
            <div className="flex-1 min-w-0">
              {children}
            </div>
          </div>
        </div>
      </main>
      
      <Footer />
    </div>
  )
}
