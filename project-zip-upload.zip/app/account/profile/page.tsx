"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"

export default function ProfilePage() {
  const [formData, setFormData] = useState({
    firstName: "Priya",
    lastName: "Sharma",
    email: "priya.sharma@email.com",
    phone: "+91 98765 43210",
    birthday: "1992-05-15",
    gender: "female",
  })

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    console.log("Profile updated:", formData)
  }

  return (
    <div>
      <h1 className="font-serif text-3xl md:text-[30px] text-foreground mb-8">
        Profile
      </h1>
      
      <form onSubmit={handleSubmit} className="max-w-xl space-y-6">
        {/* Name Fields */}
        <div className="grid grid-cols-2 gap-4">
          <div>
            <label className="block text-sm font-sans text-muted-foreground mb-2">
              First Name
            </label>
            <input
              type="text"
              value={formData.firstName}
              onChange={(e) => setFormData({ ...formData, firstName: e.target.value })}
              className="w-full h-11 px-4 border border-border bg-background text-sm font-sans text-foreground focus:outline-none focus:border-foreground transition-colors"
            />
          </div>
          <div>
            <label className="block text-sm font-sans text-muted-foreground mb-2">
              Last Name
            </label>
            <input
              type="text"
              value={formData.lastName}
              onChange={(e) => setFormData({ ...formData, lastName: e.target.value })}
              className="w-full h-11 px-4 border border-border bg-background text-sm font-sans text-foreground focus:outline-none focus:border-foreground transition-colors"
            />
          </div>
        </div>
        
        {/* Email */}
        <div>
          <label className="block text-sm font-sans text-muted-foreground mb-2">
            Email Address
          </label>
          <input
            type="email"
            value={formData.email}
            onChange={(e) => setFormData({ ...formData, email: e.target.value })}
            className="w-full h-11 px-4 border border-border bg-background text-sm font-sans text-foreground focus:outline-none focus:border-foreground transition-colors"
          />
        </div>
        
        {/* Phone */}
        <div>
          <label className="block text-sm font-sans text-muted-foreground mb-2">
            Phone Number
          </label>
          <input
            type="tel"
            value={formData.phone}
            onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
            className="w-full h-11 px-4 border border-border bg-background text-sm font-sans text-foreground focus:outline-none focus:border-foreground transition-colors"
          />
        </div>
        
        {/* Birthday & Gender */}
        <div className="grid grid-cols-2 gap-4">
          <div>
            <label className="block text-sm font-sans text-muted-foreground mb-2">
              Birthday
            </label>
            <input
              type="date"
              value={formData.birthday}
              onChange={(e) => setFormData({ ...formData, birthday: e.target.value })}
              className="w-full h-11 px-4 border border-border bg-background text-sm font-sans text-foreground focus:outline-none focus:border-foreground transition-colors"
            />
          </div>
          <div>
            <label className="block text-sm font-sans text-muted-foreground mb-2">
              Gender
            </label>
            <select
              value={formData.gender}
              onChange={(e) => setFormData({ ...formData, gender: e.target.value })}
              className="w-full h-11 px-4 border border-border bg-background text-sm font-sans text-foreground focus:outline-none focus:border-foreground transition-colors"
            >
              <option value="female">Female</option>
              <option value="male">Male</option>
              <option value="other">Other</option>
              <option value="prefer-not-to-say">Prefer not to say</option>
            </select>
          </div>
        </div>
        
        {/* Submit */}
        <Button
          type="submit"
          className="w-full h-11 bg-primary text-primary-foreground font-sans text-sm rounded-none hover:bg-primary/90"
        >
          Save Changes
        </Button>
      </form>
    </div>
  )
}
